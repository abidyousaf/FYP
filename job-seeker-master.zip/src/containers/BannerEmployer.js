import React from "react";
import CompanyCover from "../images/cover.jpg";
import CompnayLogo from "../images/company-logo.png";

export default ({ cover, logo }) => {
  let user_cover = JSON.parse(localStorage.getItem("UserAuth")).cover;
  let user_logo = JSON.parse(localStorage.getItem("UserAuth")).logo;

  return (
    <section className="company-cover">
      <img
        id="company-cover"
        src={"/" + user_cover ?'/' + user_cover : CompanyCover}
        alt=""
      />
      <div className="company-logo-wrap">
        <img
          id="company-logo"
          src={"/" + user_logo ? '/' + user_logo : CompnayLogo}
          alt="company logo"
        />
      </div>
    </section>
  );
};
